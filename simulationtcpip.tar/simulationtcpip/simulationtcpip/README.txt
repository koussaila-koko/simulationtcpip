Bonjour ,

le fichier exucutable est nomm� EXETCPIP.jar
le manuel d'utilisation vous le trouvez dans le fichier "fichier" 
un fichier � titre d'exemple nomm� testtcpip au cas de test d'importation du fichier
 
Bien cordialement,